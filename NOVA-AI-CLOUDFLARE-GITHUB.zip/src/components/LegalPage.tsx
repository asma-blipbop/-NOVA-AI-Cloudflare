export function LegalPage({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="min-h-screen nova-noise py-16 px-6">
      <div className="max-w-2xl mx-auto prose-sm">
        <h1 className="font-display text-3xl font-bold mb-8">{title}</h1>
        <div className="text-sm text-nova-text-dim leading-relaxed space-y-4">{children}</div>
      </div>
    </div>
  )
}

export function CompanyPlaceholder() {
  return (
    <p className="border border-dashed border-nova-border rounded-lg p-4 text-amber-300/90">
      [À compléter par l'administrateur] Raison sociale, forme juridique, adresse du siège, SIREN/SIRET, capital
      social, numéro de TVA intracommunautaire, directeur de la publication et hébergeur. Ces informations légales
      réelles doivent être renseignées avant la mise en production — elles ne sont pas inventées ici.
    </p>
  )
}
