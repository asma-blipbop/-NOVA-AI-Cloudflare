import { AlertTriangle } from 'lucide-react'

export function NotConfiguredPanel({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="max-w-xl nova-card p-6 flex items-start gap-3">
      <AlertTriangle size={20} className="text-amber-400 shrink-0 mt-0.5" />
      <div>
        <p className="font-medium mb-1">{title}</p>
        <p className="text-sm text-nova-text-dim">{detail}</p>
      </div>
    </div>
  )
}
