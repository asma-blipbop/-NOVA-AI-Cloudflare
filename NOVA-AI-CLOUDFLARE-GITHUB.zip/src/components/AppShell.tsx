import { Link, useRouterState } from '@tanstack/react-router'
import {
  MessageSquare,
  Search,
  FileText,
  Image as ImageIcon,
  Clapperboard,
  Code2,
  Brain,
  LibraryBig,
  Gem,
  CreditCard,
  User,
  Settings,
  ShieldCheck,
  Receipt,
  Sparkles,
} from 'lucide-react'

const NAV = [
  { to: '/app/chat', label: 'Chat', icon: MessageSquare },
  { to: '/app/search', label: 'Search', icon: Search },
  { to: '/app/docs', label: 'Docs', icon: FileText },
  { to: '/app/images', label: 'Images', icon: ImageIcon },
  { to: '/video', label: 'NOVA VIDEO', icon: Clapperboard, highlight: true },
  { to: '/app/code', label: 'Code', icon: Code2 },
  { to: '/app/memory', label: 'Memory', icon: Brain },
  { to: '/app/library', label: 'Library', icon: LibraryBig },
] as const

const NAV_BOTTOM = [
  { to: '/app/credits', label: 'Credits', icon: Gem },
  { to: '/pricing', label: 'Subscription', icon: CreditCard },
  { to: '/app/account', label: 'Account', icon: User },
  { to: '/app/billing', label: 'Billing', icon: Receipt },
  { to: '/app/settings', label: 'Settings', icon: Settings },
  { to: '/admin', label: 'Admin', icon: ShieldCheck },
] as const

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname })

  return (
    <div className="min-h-screen flex bg-nova-black">
      <aside className="w-64 shrink-0 border-r border-nova-border flex flex-col py-6 px-3">
        <Link to="/" className="flex items-center gap-2 font-display font-semibold px-3 mb-8">
          <span className="grid place-items-center size-8 rounded-lg bg-gradient-to-br from-nova-violet to-nova-blue text-white">
            <Sparkles size={16} />
          </span>
          NOVA AI
        </Link>
        <nav className="flex-1 space-y-1">
          {NAV.map((item) => {
            const active = pathname === item.to
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  active
                    ? 'bg-nova-surface-2 text-nova-text nova-glow-violet'
                    : 'text-nova-text-dim hover:text-nova-text hover:bg-nova-surface'
                } ${'highlight' in item && item.highlight && !active ? 'text-nova-violet-light' : ''}`}
              >
                <item.icon size={17} />
                {item.label}
              </Link>
            )
          })}
        </nav>
        <div className="space-y-1 pt-4 border-t border-nova-border">
          {NAV_BOTTOM.map((item) => {
            const active = pathname === item.to
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  active ? 'bg-nova-surface-2 text-nova-text' : 'text-nova-text-dim hover:text-nova-text hover:bg-nova-surface'
                }`}
              >
                <item.icon size={17} />
                {item.label}
              </Link>
            )
          })}
        </div>
      </aside>
      <main className="flex-1 min-w-0 overflow-y-auto">{children}</main>
    </div>
  )
}
