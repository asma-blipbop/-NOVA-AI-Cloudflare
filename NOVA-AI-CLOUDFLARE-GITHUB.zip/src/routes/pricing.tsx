import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Check, ExternalLink, Gem } from 'lucide-react'
import { MarketingNav, MarketingFooter } from '../components/MarketingLayout'
import { useIdentity } from '../lib/identity-context'
import { getPricingData } from '../lib/pricing-data'
import { recordPendingPayment } from '../lib/payment-actions'

export const Route = createFileRoute('/pricing')({
  component: Pricing,
  loader: () => getPricingData(),
})

function formatPrice(cents: number) {
  if (cents === 0) return '0 €'
  return `${(cents / 100).toFixed(2).replace('.', ',')} €`
}

function Pricing() {
  const { plans, packs, planLinks, packLinks } = Route.useLoaderData()
  const { user } = useIdentity()
  const [pendingTarget, setPendingTarget] = useState<string | null>(null)
  const [confirmedTargets, setConfirmedTargets] = useState<Set<string>>(new Set())

  async function handlePaid(target: string, amountCents: number, link: string) {
    window.open(link, '_blank', 'noopener,noreferrer')
    if (!user) return
    setPendingTarget(target)
    try {
      await recordPendingPayment({ data: { target, amountCents } })
      setConfirmedTargets((prev) => new Set(prev).add(target))
    } finally {
      setPendingTarget(null)
    }
  }

  return (
    <div className="min-h-screen nova-noise">
      <MarketingNav />

      <section className="py-20 px-6">
        <div className="max-w-3xl mx-auto text-center mb-14">
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">Tarifs simples, transparents</h1>
          <p className="text-nova-text-dim">Commence gratuitement, évolue quand tu es prêt. Paiement via Revolut Payment Links.</p>
        </div>

        <div className="max-w-6xl mx-auto grid md:grid-cols-3 lg:grid-cols-5 gap-4 mb-20">
          {plans.map((plan) => {
            const link = planLinks[plan.slug]
            const isPaid = plan.priceCents > 0
            const confirmed = confirmedTargets.has(`plan:${plan.slug}`)
            return (
              <div key={plan.slug} className={`nova-card p-6 flex flex-col ${plan.badge ? 'nova-glow-violet border-nova-violet' : ''}`}>
                {plan.badge && <p className="text-xs font-semibold text-nova-violet-light mb-2">{plan.badge}</p>}
                <h3 className="font-display font-semibold text-lg">{plan.name}</h3>
                <p className="text-2xl font-bold mt-1 mb-1">
                  {plan.slug === 'enterprise' ? 'Sur devis' : `${formatPrice(plan.priceCents)}/mois`}
                </p>
                <p className="text-xs text-nova-text-dim mb-4">
                  {plan.slug === 'enterprise' ? 'Volumes personnalisés' : `${plan.monthlyCredits.toLocaleString('fr-FR')} crédits/mois`}
                </p>
                <ul className="space-y-1.5 text-sm text-nova-text-dim flex-1 mb-5">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2"><Check size={14} className="mt-0.5 text-nova-blue shrink-0" />{f}</li>
                  ))}
                </ul>
                {plan.slug === 'free' ? (
                  <a href="/signup" className="w-full py-2.5 rounded-lg text-center text-sm font-semibold nova-btn-primary">Commencer</a>
                ) : plan.slug === 'enterprise' ? (
                  <a href="/legal/contact" className="w-full py-2.5 rounded-lg text-center text-sm font-semibold border border-nova-border">Contacter</a>
                ) : link ? (
                  <button
                    onClick={() => handlePaid(`plan:${plan.slug}`, plan.priceCents, link)}
                    disabled={pendingTarget === `plan:${plan.slug}`}
                    className="w-full py-2.5 rounded-lg text-center text-sm font-semibold nova-btn-primary flex items-center justify-center gap-1.5"
                  >
                    Payer via Revolut <ExternalLink size={13} />
                  </button>
                ) : (
                  <p className="text-xs text-center text-nova-text-dim border border-nova-border rounded-lg py-2.5">Lien de paiement non configuré</p>
                )}
                {confirmed && <p className="text-[11px] text-nova-blue text-center mt-2">Paiement en attente de validation manuelle</p>}
              </div>
            )
          })}
        </div>

        <div className="max-w-3xl mx-auto mb-6 nova-card p-4 text-xs text-nova-text-dim flex items-start gap-2">
          <span>ℹ️</span>
          <p>
            Une redirection vers Revolut n'est jamais considérée comme une preuve de paiement. Chaque paiement est
            enregistré en statut « en attente » jusqu'à confirmation par webhook/API Revolut ou validation manuelle
            par un administrateur.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <h2 className="font-display text-2xl font-bold mb-6 flex items-center gap-2"><Gem size={20} className="text-nova-violet-light" /> Packs de crédits</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
            {packs.map((pack) => {
              const link = packLinks[pack.id]
              const target = `pack:${pack.id}`
              const confirmed = confirmedTargets.has(target)
              return (
                <div key={pack.id} className="nova-card p-5 text-center">
                  <p className="text-2xl font-bold">{pack.credits.toLocaleString('fr-FR')}</p>
                  <p className="text-xs text-nova-text-dim mb-4">crédits</p>
                  <p className="font-semibold mb-4">{formatPrice(pack.priceCents)}</p>
                  {link ? (
                    <button
                      onClick={() => handlePaid(target, pack.priceCents, link)}
                      disabled={pendingTarget === target}
                      className="w-full py-2 rounded-lg text-sm font-semibold nova-btn-primary"
                    >
                      Acheter
                    </button>
                  ) : (
                    <p className="text-[11px] text-nova-text-dim border border-nova-border rounded-lg py-2">Non configuré</p>
                  )}
                  {confirmed && <p className="text-[11px] text-nova-blue mt-2">En attente de validation</p>}
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <MarketingFooter />
    </div>
  )
}
