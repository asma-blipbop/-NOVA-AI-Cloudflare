import { createFileRoute, Link } from '@tanstack/react-router'
import {
  MessageSquare,
  Search,
  FileText,
  Image as ImageIcon,
  Clapperboard,
  Code2,
  Brain,
  ArrowRight,
  Camera,
  Film,
  Smartphone,
} from 'lucide-react'
import { MarketingNav, MarketingFooter } from '../components/MarketingLayout'

export const Route = createFileRoute('/')({
  component: Home,
})

const FEATURES = [
  { icon: MessageSquare, title: 'NOVA Chat', desc: 'Streaming, Markdown, code, fichiers, mémoire et sélection de modèle.' },
  { icon: Search, title: 'NOVA Search', desc: 'Recherche web réelle avec sources citées et synthèse.' },
  { icon: FileText, title: 'NOVA Docs', desc: 'PDF, DOCX, XLSX, images — résumé, extraction, traduction.' },
  { icon: ImageIcon, title: 'NOVA Image', desc: 'Génération text-to-image, variations, styles, galerie.' },
  { icon: Clapperboard, title: 'NOVA VIDEO', desc: 'Studio de génération vidéo IA — text-to-video et image-to-video.' },
  { icon: Code2, title: 'NOVA Code', desc: 'Génération, correction, refactoring et export de code.' },
  { icon: Brain, title: 'Mémoire', desc: 'Une mémoire personnelle que tu contrôles entièrement.' },
]

const VIDEO_PRESETS = [
  { emoji: '📸', label: 'Photorealistic' },
  { emoji: '🎥', label: 'Cinematic' },
  { emoji: '📱', label: 'Social Media' },
  { emoji: '🎞️', label: 'Commercial' },
  { emoji: '🚗', label: 'Automotive' },
  { emoji: '🏙️', label: 'Architecture' },
]

function Home() {
  return (
    <div className="min-h-screen nova-noise">
      <MarketingNav />

      {/* Hero */}
      <section className="relative py-28 px-6 overflow-hidden">
        <div className="max-w-4xl mx-auto text-center animate-fade-up">
          <p className="inline-flex items-center gap-2 text-xs font-medium tracking-wide uppercase text-nova-violet-light border border-nova-border rounded-full px-4 py-1.5 mb-8">
            <span className="size-1.5 rounded-full bg-nova-violet animate-pulse-slow" />
            Studio IA tout-en-un
          </p>
          <h1 className="font-display text-6xl md:text-8xl font-bold tracking-tight mb-6">
            NOVA <span className="nova-gradient-text">AI</span>
          </h1>
          <p className="text-2xl md:text-3xl font-display font-medium mb-6">Toute l'IA. Un seul espace.</p>
          <p className="text-lg text-nova-text-dim max-w-2xl mx-auto mb-10">
            Crée, imagine, analyse, recherche et transforme tes idées avec l'intelligence artificielle.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/signup" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl nova-btn-primary">
              ✨ Commencer gratuitement <ArrowRight size={16} />
            </Link>
            <Link
              to="/video"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl border border-nova-border nova-glass font-semibold"
            >
              🎬 Créer une vidéo
            </Link>
            <Link
              to="/pricing"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl text-nova-text-dim hover:text-nova-text font-semibold"
            >
              Voir les tarifs
            </Link>
          </div>
        </div>
      </section>

      {/* NOVA VIDEO showcase */}
      <section className="py-24 px-6 border-t border-nova-border">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-sm font-medium text-nova-blue mb-3 uppercase tracking-wide">Fonctionnalité phare</p>
              <h2 className="font-display text-4xl md:text-5xl font-bold mb-5">🎬 NOVA VIDEO</h2>
              <p className="text-lg text-nova-text-dim mb-6">Transforme une idée en vidéo.</p>
              <p className="text-nova-text-dim mb-8 leading-relaxed">
                Décris une scène ou anime une image : NOVA VIDEO transmet réellement ta demande au fournisseur vidéo
                configuré par l'administrateur — mouvements de caméra, presets cinématiques, formats verticaux pour
                TikTok/Reels/Shorts, et un système de jobs asynchrone avec galerie de créations.
              </p>
              <div className="flex flex-wrap gap-2 mb-8">
                {VIDEO_PRESETS.map((p) => (
                  <span key={p.label} className="nova-card px-3 py-1.5 text-sm flex items-center gap-1.5">
                    <span>{p.emoji}</span>
                    {p.label}
                  </span>
                ))}
              </div>
              <Link to="/video" className="inline-flex items-center gap-2 nova-btn-primary px-6 py-3 rounded-xl">
                Ouvrir le studio NOVA VIDEO <ArrowRight size={16} />
              </Link>
            </div>
            <div className="nova-card nova-glow-violet p-8 aspect-[9/12] flex flex-col justify-between">
              <div className="flex items-center justify-between text-sm text-nova-text-dim">
                <span className="flex items-center gap-1.5"><Film size={14} /> Aperçu du studio</span>
                <span className="flex items-center gap-1.5"><Smartphone size={14} /> 9:16</span>
              </div>
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center text-nova-text-dim px-6">
                  <Camera size={40} className="mx-auto mb-4 text-nova-violet-light" />
                  <p className="text-sm">
                    Aucune démonstration vidéo n'est publiée ici tant qu'aucun fournisseur vidéo réel n'est configuré —
                    NOVA AI ne simule jamais une génération.
                  </p>
                </div>
              </div>
              <div className="text-xs text-nova-text-dim border-t border-nova-border pt-4">
                État actuel : <span className="text-nova-violet-light">fournisseur non configuré</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features grid */}
      <section className="py-24 px-6 border-t border-nova-border">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-4">Un vrai studio IA professionnel</h2>
          <p className="text-center text-nova-text-dim mb-14 max-w-xl mx-auto">
            Chaque module est connecté à de vrais fournisseurs IA — jamais de résultat simulé.
          </p>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5">
            {FEATURES.map((f) => (
              <div key={f.title} className="nova-card p-6 hover:nova-glow-violet transition-shadow">
                <div className="size-11 rounded-lg bg-nova-surface-2 border border-nova-border grid place-items-center mb-4 text-nova-violet-light">
                  <f.icon size={20} />
                </div>
                <h3 className="font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-nova-text-dim leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6 border-t border-nova-border text-center">
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Prêt à créer ?</h2>
        <p className="text-nova-text-dim mb-8">150 crédits gratuits chaque mois pour découvrir NOVA AI.</p>
        <Link to="/signup" className="inline-flex items-center gap-2 nova-btn-primary px-8 py-3.5 rounded-xl">
          ✨ Commencer gratuitement <ArrowRight size={16} />
        </Link>
      </section>

      <MarketingFooter />
    </div>
  )
}
