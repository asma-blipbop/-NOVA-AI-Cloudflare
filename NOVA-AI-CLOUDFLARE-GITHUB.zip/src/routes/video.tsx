import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Sparkles, Wand2, Clapperboard, ImagePlus, Type, AlertTriangle, Play, Download, Heart, RotateCcw, Trash2, Loader2 } from 'lucide-react'
import { MarketingNav, MarketingFooter } from '../components/MarketingLayout'
import { useIdentity } from '../lib/identity-context'
import { getVideoCatalog, createVideoJob, getMyVideoGenerations } from '../lib/video-actions'
import { enhanceVideoPrompt } from '../lib/prompt-enhancer'

export const Route = createFileRoute('/video')({
  component: VideoStudio,
  loader: async () => {
    const models = await getVideoCatalog()
    return { models }
  },
})

const STYLE_PRESETS = [
  { key: 'photorealistic', emoji: '📸', label: 'Photorealistic', desc: 'Rendu réaliste' },
  { key: 'cinematic', emoji: '🎥', label: 'Cinematic', desc: 'Look cinéma' },
  { key: 'social', emoji: '📱', label: 'Social Media', desc: 'TikTok / Reels / Shorts' },
  { key: 'commercial', emoji: '🎞️', label: 'Commercial', desc: 'Publicité pro' },
  { key: 'real_world', emoji: '🌆', label: 'Real World', desc: 'Scènes du quotidien' },
  { key: 'automotive', emoji: '🚗', label: 'Automotive', desc: 'Voitures & plans auto' },
  { key: 'architecture', emoji: '🏙️', label: 'Architecture', desc: 'Immobilier / villes' },
  { key: 'human', emoji: '👤', label: 'Human', desc: 'Personnages & scènes humaines' },
  { key: 'travel', emoji: '🌄', label: 'Travel', desc: 'Voyage / paysages' },
  { key: 'creative', emoji: '🎮', label: 'Creative', desc: 'Styles créatifs' },
]

const RATIO_CARDS = [
  { key: '16:9', label: '16:9', desc: 'YouTube / télévision' },
  { key: '9:16', label: '9:16', desc: 'TikTok / Reels / Shorts' },
  { key: '1:1', label: '1:1', desc: 'Réseaux sociaux' },
]

type VideoModel = Awaited<ReturnType<typeof getVideoCatalog>>[number]

function VideoStudio() {
  const { models } = Route.useLoaderData()
  const { user, ready } = useIdentity()

  const [mode, setMode] = useState<'text_to_video' | 'image_to_video'>('text_to_video')
  const [idea, setIdea] = useState('')
  const [enhancing, setEnhancing] = useState(false)
  const [selectedModel, setSelectedModel] = useState<VideoModel | undefined>(models[0])
  const [preset, setPreset] = useState('cinematic')
  const [ratio, setRatio] = useState('16:9')
  const [duration, setDuration] = useState<number | undefined>(models[0]?.supportedDurationsSeconds[0])
  const [submitting, setSubmitting] = useState(false)
  const [feedback, setFeedback] = useState<{ type: 'error' | 'info'; message: string } | null>(null)
  const [generations, setGenerations] = useState<Awaited<ReturnType<typeof getMyVideoGenerations>>>([])

  useEffect(() => {
    setDuration(selectedModel?.supportedDurationsSeconds[0])
    if (selectedModel && !selectedModel.supportedRatios.includes(ratio)) {
      setRatio(selectedModel.supportedRatios[0] ?? '16:9')
    }
  }, [selectedModel])

  useEffect(() => {
    if (!ready || !user) return
    getMyVideoGenerations().then(setGenerations).catch(() => {})
  }, [ready, user])

  async function handleEnhance() {
    if (!idea.trim()) return
    setEnhancing(true)
    try {
      const { enhancedPrompt } = await enhanceVideoPrompt({ data: { idea } })
      setIdea(enhancedPrompt)
    } catch {
      setFeedback({ type: 'error', message: "Impossible d'améliorer le prompt pour le moment." })
    } finally {
      setEnhancing(false)
    }
  }

  async function handleGenerate() {
    setFeedback(null)
    if (!user) {
      setFeedback({ type: 'error', message: 'Connecte-toi pour lancer une génération.' })
      return
    }
    if (!selectedModel) {
      setFeedback({ type: 'error', message: "Aucun modèle vidéo n'est configuré par l'administration pour le moment." })
      return
    }
    if (!duration) return
    setSubmitting(true)
    try {
      await createVideoJob({
        data: {
          modelSlug: selectedModel.slug,
          mode,
          prompt: idea,
          stylePreset: preset,
          ratio,
          durationSeconds: duration,
        },
      })
      const updated = await getMyVideoGenerations()
      setGenerations(updated)
      setFeedback({ type: 'info', message: 'Job créé. Suis son statut dans "Mes créations" ci-dessous.' })
    } catch (err: any) {
      setFeedback({ type: 'error', message: err?.message ?? 'La génération a échoué.' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen nova-noise">
      <MarketingNav />

      <section className="py-16 px-6">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <p className="inline-flex items-center gap-2 text-xs font-medium tracking-wide uppercase text-nova-blue border border-nova-border rounded-full px-4 py-1.5 mb-6">
            <Clapperboard size={13} /> NOVA VIDEO
          </p>
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">Transforme une idée en vidéo.</h1>
          <p className="text-nova-text-dim">
            Décris ta scène, choisis un style et un format — NOVA VIDEO transmet réellement ta demande au fournisseur
            vidéo configuré par l'administration.
          </p>
        </div>

        {models.length === 0 && (
          <div className="max-w-3xl mx-auto mb-8 nova-card border-amber-500/30 p-4 flex items-start gap-3 text-sm">
            <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <p className="text-nova-text-dim">
              <span className="text-amber-300 font-medium">Aucun fournisseur vidéo n'est configuré</span> pour le
              moment. L'interface ci-dessous est entièrement fonctionnelle et représente le flux réel (crédits,
              file d'attente, jobs) — mais aucune vidéo ne peut encore être générée. Ajoute un provider vidéo actif
              dans l'administration pour l'activer.
            </p>
          </div>
        )}

        <div className="max-w-3xl mx-auto nova-card nova-glow-violet p-6 md:p-8 space-y-7">
          {/* Mode toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => setMode('text_to_video')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium border transition-colors ${mode === 'text_to_video' ? 'border-nova-violet bg-nova-surface-2 text-nova-text' : 'border-nova-border text-nova-text-dim'}`}
            >
              <Type size={15} /> Texte → Vidéo
            </button>
            <button
              onClick={() => setMode('image_to_video')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium border transition-colors ${mode === 'image_to_video' ? 'border-nova-violet bg-nova-surface-2 text-nova-text' : 'border-nova-border text-nova-text-dim'}`}
            >
              <ImagePlus size={15} /> Image → Vidéo
            </button>
          </div>

          {mode === 'image_to_video' && (
            <div className="border border-dashed border-nova-border rounded-xl p-8 text-center text-sm text-nova-text-dim">
              Import d'image — nécessite le stockage objet et un fournisseur image-to-video configurés.
            </div>
          )}

          {/* Prompt */}
          <div>
            <label className="text-sm font-medium mb-2 block">Décris ta vidéo</label>
            <textarea
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              rows={4}
              placeholder="Une voiture sportive noire roule rapidement sur une route de montagne au coucher du soleil, caméra cinématique basse, reflets réalistes sur la carrosserie, mouvement naturel, profondeur de champ, rendu photoréaliste."
              className="w-full bg-nova-surface-2 border border-nova-border rounded-xl p-4 text-sm resize-none focus:outline-none focus:border-nova-violet"
            />
            <button
              onClick={handleEnhance}
              disabled={enhancing || !idea.trim()}
              className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-nova-violet-light hover:text-nova-blue disabled:opacity-40"
            >
              {enhancing ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
              Améliorer mon prompt
            </button>
          </div>

          {/* Style presets */}
          <div>
            <label className="text-sm font-medium mb-2 block">Style vidéo</label>
            <div className="flex flex-wrap gap-2">
              {STYLE_PRESETS.map((p) => (
                <button
                  key={p.key}
                  onClick={() => setPreset(p.key)}
                  title={p.desc}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${preset === p.key ? 'border-nova-violet bg-nova-surface-2' : 'border-nova-border text-nova-text-dim'}`}
                >
                  {p.emoji} {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Format cards */}
          <div>
            <label className="text-sm font-medium mb-2 block">Format</label>
            <div className="grid grid-cols-3 gap-3">
              {RATIO_CARDS.map((r) => {
                const supported = !selectedModel || selectedModel.supportedRatios.includes(r.key)
                return (
                  <button
                    key={r.key}
                    disabled={!supported}
                    onClick={() => setRatio(r.key)}
                    className={`p-3 rounded-lg border text-center transition-colors ${ratio === r.key ? 'border-nova-violet bg-nova-surface-2' : 'border-nova-border'} ${!supported ? 'opacity-30 cursor-not-allowed' : ''}`}
                  >
                    <p className="font-semibold text-sm">{r.label}</p>
                    <p className="text-[11px] text-nova-text-dim">{r.desc}</p>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Duration + model */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Durée</label>
              <select
                value={duration ?? ''}
                onChange={(e) => setDuration(Number(e.target.value))}
                disabled={!selectedModel}
                className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-3 py-2.5 text-sm disabled:opacity-40"
              >
                {(selectedModel?.supportedDurationsSeconds ?? []).map((d) => (
                  <option key={d} value={d}>{d} secondes</option>
                ))}
                {!selectedModel && <option>Indisponible</option>}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Modèle vidéo</label>
              <select
                value={selectedModel?.slug ?? ''}
                onChange={(e) => setSelectedModel(models.find((m) => m.slug === e.target.value))}
                disabled={models.length === 0}
                className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-3 py-2.5 text-sm disabled:opacity-40"
              >
                {models.length === 0 && <option>Aucun modèle configuré</option>}
                {models.map((m) => (
                  <option key={m.slug} value={m.slug}>{m.name}</option>
                ))}
              </select>
            </div>
          </div>

          {feedback && (
            <p className={`text-sm ${feedback.type === 'error' ? 'text-red-400' : 'text-nova-blue'}`}>{feedback.message}</p>
          )}

          <button
            onClick={handleGenerate}
            disabled={submitting || !idea.trim()}
            className="w-full nova-btn-primary rounded-xl py-3.5 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {submitting ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
            {submitting ? 'Création de ta vidéo…' : 'Générer la vidéo'}
          </button>
        </div>
      </section>

      {/* Gallery */}
      {user && (
        <section className="py-16 px-6 border-t border-nova-border">
          <div className="max-w-5xl mx-auto">
            <h2 className="font-display text-2xl font-bold mb-6">Mes créations</h2>
            {generations.length === 0 ? (
              <p className="text-sm text-nova-text-dim">Aucune génération pour le moment.</p>
            ) : (
              <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
                {generations.map((g) => (
                  <div key={g.id} className="nova-card p-4">
                    <div className="aspect-video rounded-lg bg-nova-surface-2 border border-nova-border grid place-items-center mb-3 text-nova-text-dim text-xs">
                      {g.job?.status === 'completed' ? <Play size={20} /> : <StatusBadge status={g.job?.status ?? 'queued'} />}
                    </div>
                    <p className="text-sm line-clamp-2 mb-2">{g.prompt}</p>
                    <div className="flex items-center justify-between text-[11px] text-nova-text-dim mb-3">
                      <span>{g.durationSeconds}s · {g.ratio}</span>
                      <span>{g.creditsCost} crédits</span>
                    </div>
                    {g.job?.status === 'failed' && (
                      <p className="text-[11px] text-red-400 mb-3">{g.job.statusMessage}</p>
                    )}
                    <div className="flex items-center gap-3 text-nova-text-dim">
                      <Download size={14} className="opacity-40" />
                      <Heart size={14} className="opacity-40" />
                      <RotateCcw size={14} className="opacity-40" />
                      <Trash2 size={14} className="opacity-40" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      <MarketingFooter />
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    queued: '⏳ En file',
    processing: '✨ Création en cours…',
    completed: '🎉 Terminée',
    failed: '⚠️ Échouée',
    cancelled: 'Annulée',
  }
  return <span>{labels[status] ?? status}</span>
}
