import { createFileRoute, redirect } from '@tanstack/react-router'
import { Search } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { NotConfiguredPanel } from '../../components/NotConfiguredPanel'
import { getServerUser } from '../../lib/auth'

export const Route = createFileRoute('/app/search')({
  component: SearchPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
})

function SearchPage() {
  return (
    <AppShell>
      <div className="max-w-3xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <Search size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">NOVA Search</h1>
        </div>
        <p className="text-sm text-nova-text-dim mb-6">
          Question → Recherche → Sources → Analyse → Réponse. NOVA Search interroge un fournisseur de recherche web
          réel puis cite ses sources — il n'y a pas de résultat sans fournisseur connecté.
        </p>
        <NotConfiguredPanel
          title="Fournisseur de recherche web non configuré"
          detail="Ajoute une clé d'API de recherche (ex. Brave Search, Tavily, Exa) dans les variables d'environnement du site pour activer NOVA Search."
        />
      </div>
    </AppShell>
  )
}
