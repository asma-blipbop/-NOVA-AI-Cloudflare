import { createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { Code2, Loader2, Sparkles } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'
import { runCodeAssistant } from '../../lib/code-actions'

export const Route = createFileRoute('/app/code')({
  component: CodePage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
})

const ACTIONS = [
  { key: 'generate', label: 'Générer' },
  { key: 'fix', label: 'Corriger' },
  { key: 'explain', label: 'Expliquer' },
  { key: 'refactor', label: 'Refactoriser' },
  { key: 'optimize', label: 'Optimiser' },
] as const

function CodePage() {
  const [code, setCode] = useState('')
  const [action, setAction] = useState<typeof ACTIONS[number]['key']>('generate')
  const [instructions, setInstructions] = useState('')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleRun() {
    setLoading(true)
    setError('')
    try {
      const res = await runCodeAssistant({ data: { action, code, instructions } })
      setResult(res.output)
    } catch (err: any) {
      setError(err?.message ?? 'Erreur')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AppShell>
      <div className="max-w-4xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <Code2 size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">NOVA Code</h1>
        </div>
        <div className="flex gap-2 mb-4">
          {ACTIONS.map((a) => (
            <button
              key={a.key}
              onClick={() => setAction(a.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${action === a.key ? 'border-nova-violet bg-nova-surface-2' : 'border-nova-border text-nova-text-dim'}`}
            >
              {a.label}
            </button>
          ))}
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              rows={12}
              placeholder="Colle ton code ici (optionnel pour 'générer')…"
              className="w-full bg-nova-surface-2 border border-nova-border rounded-xl p-4 text-xs font-mono resize-none focus:outline-none focus:border-nova-violet"
            />
            <input
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Instructions (ex: 'ajoute la gestion des erreurs')"
              className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm"
            />
            <button onClick={handleRun} disabled={loading} className="nova-btn-primary rounded-xl py-2.5 w-full flex items-center justify-center gap-2">
              {loading ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}
              Exécuter
            </button>
            {error && <p className="text-sm text-red-400">{error}</p>}
          </div>
          <pre className="bg-nova-surface-2 border border-nova-border rounded-xl p-4 text-xs font-mono overflow-auto whitespace-pre-wrap min-h-[300px]">
            {result || 'Le résultat apparaîtra ici.'}
          </pre>
        </div>
      </div>
    </AppShell>
  )
}
