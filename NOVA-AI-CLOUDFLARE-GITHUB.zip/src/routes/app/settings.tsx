import { createFileRoute, redirect } from '@tanstack/react-router'
import { Settings } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { getServerUser } from '../../lib/auth'

export const Route = createFileRoute('/app/settings')({
  component: SettingsPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
})

function SettingsPage() {
  return (
    <AppShell>
      <div className="max-w-2xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <Settings size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">Paramètres</h1>
        </div>
        <div className="nova-card p-6 space-y-4">
          <label className="flex items-center justify-between text-sm">
            Thème sombre
            <input type="checkbox" defaultChecked disabled className="accent-nova-violet" />
          </label>
          <label className="flex items-center justify-between text-sm">
            Recevoir les emails marketing
            <input type="checkbox" className="accent-nova-violet" />
          </label>
        </div>
      </div>
    </AppShell>
  )
}
