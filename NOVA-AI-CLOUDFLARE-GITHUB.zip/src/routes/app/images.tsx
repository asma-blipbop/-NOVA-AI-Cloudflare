import { createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { Image as ImageIcon, Sparkles } from 'lucide-react'
import { AppShell } from '../../components/AppShell'
import { NotConfiguredPanel } from '../../components/NotConfiguredPanel'
import { getServerUser } from '../../lib/auth'

export const Route = createFileRoute('/app/images')({
  component: ImagesPage,
  beforeLoad: async () => {
    const user = await getServerUser()
    if (!user) throw redirect({ to: '/login' })
  },
})

const RATIOS = ['1:1', '16:9', '9:16', '4:3']

function ImagesPage() {
  const [prompt, setPrompt] = useState('')
  const [ratio, setRatio] = useState('1:1')

  return (
    <AppShell>
      <div className="max-w-3xl mx-auto py-8 px-6">
        <div className="flex items-center gap-2 mb-6">
          <ImageIcon size={20} className="text-nova-violet-light" />
          <h1 className="font-display text-xl font-bold">NOVA Image</h1>
        </div>
        <div className="nova-card p-6 space-y-4 mb-6">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={3}
            placeholder="Décris l'image à générer…"
            className="w-full bg-nova-surface-2 border border-nova-border rounded-xl p-4 text-sm resize-none focus:outline-none focus:border-nova-violet"
          />
          <div className="flex gap-2">
            {RATIOS.map((r) => (
              <button
                key={r}
                onClick={() => setRatio(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${ratio === r ? 'border-nova-violet bg-nova-surface-2' : 'border-nova-border text-nova-text-dim'}`}
              >
                {r}
              </button>
            ))}
          </div>
          <button disabled className="nova-btn-primary rounded-xl py-3 w-full flex items-center justify-center gap-2 opacity-50 cursor-not-allowed">
            <Sparkles size={16} /> Générer (fournisseur requis)
          </button>
        </div>
        <NotConfiguredPanel
          title="Fournisseur d'image non configuré"
          detail="Ajoute un fournisseur text-to-image (ex. Stability, OpenAI Images, Google Imagen) dans l'administration pour activer NOVA Image."
        />
      </div>
    </AppShell>
  )
}
