import { createFileRoute, useNavigate, Link } from '@tanstack/react-router'
import { useState } from 'react'
import { Sparkles } from 'lucide-react'
import { signup } from '@netlify/identity'
import { useIdentity } from '../lib/identity-context'

export const Route = createFileRoute('/signup')({
  component: SignupPage,
})

function SignupPage() {
  const { user, ready } = useIdentity()
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)

  if (ready && user) {
    navigate({ to: '/app/chat' })
    return null
  }

  async function handleSignup() {
    setError('')
    setLoading(true)
    try {
      await signup(email, password, { full_name: name })
      setSent(true)
    } catch (err: any) {
      setError(err?.message ?? 'Inscription impossible')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen nova-noise flex items-center justify-center px-6">
      <div className="w-full max-w-sm nova-card p-8">
        <Link to="/" className="flex items-center gap-2 font-display font-semibold mb-8">
          <span className="grid place-items-center size-8 rounded-lg bg-gradient-to-br from-nova-violet to-nova-blue text-white">
            <Sparkles size={16} />
          </span>
          NOVA AI
        </Link>
        {sent ? (
          <p className="text-sm text-nova-text-dim">
            Un email de confirmation a été envoyé à <span className="text-nova-text">{email}</span>. Clique sur le lien pour activer ton compte et recevoir tes 150 crédits gratuits.
          </p>
        ) : (
          <>
            <h1 className="font-display text-xl font-bold mb-6">Commencer gratuitement</h1>
            <div className="space-y-3">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom" className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm" />
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm" />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Mot de passe" className="w-full bg-nova-surface-2 border border-nova-border rounded-lg px-4 py-2.5 text-sm" />
              {error && <p className="text-sm text-red-400">{error}</p>}
              <button onClick={handleSignup} disabled={loading} className="w-full nova-btn-primary rounded-lg py-2.5 text-sm">
                {loading ? 'Création…' : '✨ Créer mon compte'}
              </button>
            </div>
          </>
        )}
        <p className="text-xs text-nova-text-dim mt-6 text-center">
          Déjà un compte ? <Link to="/login" className="text-nova-violet-light">Se connecter</Link>
        </p>
      </div>
    </div>
  )
}
