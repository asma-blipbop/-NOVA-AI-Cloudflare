import { createFileRoute } from '@tanstack/react-router'
import { LegalPage } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/cgv')({ component: Page })

function Page() {
  return (
    <LegalPage title="Conditions générales de vente">
      <p>Les abonnements et packs de crédits NOVA AI sont payables via Revolut Payment Links. Les tarifs affichés sur la page Tarifs sont ceux en vigueur au moment de l'achat, sauf promotion active.</p>
      <p>Un paiement n'est considéré confirmé qu'après validation par webhook/API Revolut ou, à défaut, validation manuelle par un administrateur — jamais sur simple redirection.</p>
      <p>Les crédits sont crédités uniquement après confirmation du paiement. Les abonnements se renouvellent selon la périodicité choisie et peuvent être annulés à tout moment pour la période suivante.</p>
      <p>Conformément au droit de la consommation applicable en France et dans l'Union européenne, le droit de rétractation et les conditions de remboursement sont détaillés sur la page <a href="/legal/remboursement" className="text-nova-violet-light">Politique de remboursement</a>.</p>
    </LegalPage>
  )
}
