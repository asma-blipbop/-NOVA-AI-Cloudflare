import { createFileRoute } from '@tanstack/react-router'
import { LegalPage } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/cookies')({ component: Page })

function Page() {
  return (
    <LegalPage title="Politique de cookies">
      <p>NOVA AI utilise un cookie d'authentification (Netlify Identity, "nf_jwt") strictement nécessaire pour maintenir ta session connectée. Ce cookie ne sert pas à du traçage publicitaire.</p>
      <p>Aucun cookie de mesure d'audience ou publicitaire tiers n'est déposé sans ton consentement explicite.</p>
    </LegalPage>
  )
}
