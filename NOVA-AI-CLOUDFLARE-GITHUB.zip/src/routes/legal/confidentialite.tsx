import { createFileRoute } from '@tanstack/react-router'
import { LegalPage } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/confidentialite')({ component: Page })

function Page() {
  return (
    <LegalPage title="Politique de confidentialité">
      <p>NOVA AI collecte les données nécessaires au fonctionnement du service : identité de compte, historique de conversation, générations, transactions de crédits et de paiement.</p>
      <p>Conformément au RGPD, tu peux à tout moment demander l'accès, la rectification, l'export ou la suppression de tes données personnelles depuis la page Compte ou en écrivant via la page Contact.</p>
      <p>Les contenus envoyés à NOVA Chat, NOVA Search, NOVA Image ou NOVA VIDEO peuvent être transmis aux fournisseurs d'IA tiers configurés pour traitement, selon leurs propres politiques de confidentialité.</p>
      <p>Les données de paiement transitent par Revolut ; NOVA AI ne stocke pas les identifiants bancaires.</p>
    </LegalPage>
  )
}
