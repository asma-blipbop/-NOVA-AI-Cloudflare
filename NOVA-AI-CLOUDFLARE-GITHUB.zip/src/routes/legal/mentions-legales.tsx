import { createFileRoute } from '@tanstack/react-router'
import { LegalPage, CompanyPlaceholder } from '../../components/LegalPage'

export const Route = createFileRoute('/legal/mentions-legales')({ component: Page })

function Page() {
  return (
    <LegalPage title="Mentions légales">
      <p>Le présent site est édité par la société exploitant NOVA AI.</p>
      <CompanyPlaceholder />
      <p>Contact : voir la page <a href="/legal/contact" className="text-nova-violet-light">Contact</a>.</p>
    </LegalPage>
  )
}
