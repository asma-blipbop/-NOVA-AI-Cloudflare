import { eq } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { videoModels, videoProviders } from '../../db/schema.js'

export type VideoModelWithProvider = Awaited<ReturnType<typeof listEnabledVideoModels>>[number]

/** Returns only models whose provider is enabled and has a resolvable API key. Never fabricates data. */
export async function listEnabledVideoModels() {
  const models = await db
    .select({
      id: videoModels.id,
      slug: videoModels.slug,
      name: videoModels.name,
      description: videoModels.description,
      supportsTextToVideo: videoModels.supportsTextToVideo,
      supportsImageToVideo: videoModels.supportsImageToVideo,
      supportedDurationsSeconds: videoModels.supportedDurationsSeconds,
      supportedRatios: videoModels.supportedRatios,
      supportedResolutions: videoModels.supportedResolutions,
      costPerGeneration: videoModels.costPerGeneration,
      enabled: videoModels.enabled,
      providerName: videoProviders.name,
      providerSlug: videoProviders.slug,
      providerEnabled: videoProviders.enabled,
      apiKeyEnvVar: videoProviders.apiKeyEnvVar,
    })
    .from(videoModels)
    .innerJoin(videoProviders, eq(videoModels.providerId, videoProviders.id))

  return models.filter((m) => m.enabled && m.providerEnabled && !!process.env[m.apiKeyEnvVar])
}

export class VideoProviderNotConfiguredError extends Error {
  constructor(modelSlug: string) {
    super(
      `Fournisseur non configuré pour le modèle "${modelSlug}". Ajoutez un VideoProvider actif avec sa clé API dans l'administration pour activer la génération.`,
    )
  }
}

/**
 * Submits a generation request to the real video provider API for the given model.
 * There is intentionally no simulated/mocked response here — if no provider is wired
 * up (the common case until an admin configures one), this throws rather than
 * pretending a video was generated.
 */
export async function submitToVideoProvider(params: {
  modelSlug: string
  mode: 'text_to_video' | 'image_to_video' | 'variation'
  prompt: string
  ratio: string
  durationSeconds: number
  sourceImageUrl?: string
}): Promise<{ providerJobId: string }> {
  const [model] = await listEnabledVideoModels().then((all) => all.filter((m) => m.slug === params.modelSlug))
  if (!model) throw new VideoProviderNotConfiguredError(params.modelSlug)

  // NOTE for future integration: each provider has a distinct request contract.
  // Add a `case` here per `model.providerSlug` that calls the provider's real API
  // using the key resolved from `process.env[model.apiKeyEnvVar]`, and returns the
  // real provider job id used later for webhook/polling reconciliation.
  throw new VideoProviderNotConfiguredError(params.modelSlug)
}
