import { eq, sql } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { creditBalances, creditTransactions } from '../../db/schema.js'

export class InsufficientCreditsError extends Error {
  constructor() {
    super('Solde de crédits insuffisant')
  }
}

async function ensureBalanceRow(userId: string) {
  const existing = await db.query.creditBalances.findFirst({ where: eq(creditBalances.userId, userId) })
  if (existing) return existing
  const [row] = await db.insert(creditBalances).values({ userId, balance: 0, reserved: 0 }).returning()
  return row
}

/** Reserve credits for an async job (e.g. a video generation). Idempotent per idempotencyKey. */
export async function reserveCredits(params: {
  userId: string
  amount: number
  reason: string
  referenceType: string
  referenceId: string
  idempotencyKey: string
}) {
  const existingTx = await db.query.creditTransactions.findFirst({
    where: eq(creditTransactions.idempotencyKey, params.idempotencyKey),
  })
  if (existingTx) return { alreadyProcessed: true }

  const balance = await ensureBalanceRow(params.userId)
  const available = balance.balance - balance.reserved
  if (available < params.amount) throw new InsufficientCreditsError()

  await db.transaction(async (tx) => {
    await tx
      .update(creditBalances)
      .set({ reserved: sql`${creditBalances.reserved} + ${params.amount}`, updatedAt: new Date() })
      .where(eq(creditBalances.userId, params.userId))

    await tx.insert(creditTransactions).values({
      userId: params.userId,
      type: 'reserve',
      amount: -params.amount,
      balanceAfter: balance.balance - params.amount,
      reason: params.reason,
      referenceType: params.referenceType,
      referenceId: params.referenceId,
      idempotencyKey: params.idempotencyKey,
    })
  })

  return { alreadyProcessed: false }
}

/** Capture previously reserved credits once a job succeeds — moves them from reserved to spent. */
export async function captureReservedCredits(params: {
  userId: string
  amount: number
  reason: string
  referenceType: string
  referenceId: string
  idempotencyKey: string
}) {
  const existingTx = await db.query.creditTransactions.findFirst({
    where: eq(creditTransactions.idempotencyKey, params.idempotencyKey),
  })
  if (existingTx) return { alreadyProcessed: true }

  await db.transaction(async (tx) => {
    const [balance] = await tx
      .update(creditBalances)
      .set({
        balance: sql`${creditBalances.balance} - ${params.amount}`,
        reserved: sql`${creditBalances.reserved} - ${params.amount}`,
        updatedAt: new Date(),
      })
      .where(eq(creditBalances.userId, params.userId))
      .returning()

    await tx.insert(creditTransactions).values({
      userId: params.userId,
      type: 'capture',
      amount: -params.amount,
      balanceAfter: balance.balance,
      reason: params.reason,
      referenceType: params.referenceType,
      referenceId: params.referenceId,
      idempotencyKey: params.idempotencyKey,
    })
  })

  return { alreadyProcessed: false }
}

/** Release previously reserved credits without charging — used when a job fails or is cancelled. */
export async function releaseReservedCredits(params: {
  userId: string
  amount: number
  reason: string
  referenceType: string
  referenceId: string
  idempotencyKey: string
}) {
  const existingTx = await db.query.creditTransactions.findFirst({
    where: eq(creditTransactions.idempotencyKey, params.idempotencyKey),
  })
  if (existingTx) return { alreadyProcessed: true }

  await db.transaction(async (tx) => {
    const [balance] = await tx
      .update(creditBalances)
      .set({ reserved: sql`${creditBalances.reserved} - ${params.amount}`, updatedAt: new Date() })
      .where(eq(creditBalances.userId, params.userId))
      .returning()

    await tx.insert(creditTransactions).values({
      userId: params.userId,
      type: 'release',
      amount: 0,
      balanceAfter: balance.balance,
      reason: params.reason,
      referenceType: params.referenceType,
      referenceId: params.referenceId,
      idempotencyKey: params.idempotencyKey,
    })
  })

  return { alreadyProcessed: false }
}

/** Grant credits (subscription renewal, admin adjustment, pack purchase). Idempotent per idempotencyKey. */
export async function grantCredits(params: {
  userId: string
  amount: number
  reason: string
  referenceType?: string
  referenceId?: string
  idempotencyKey: string
}) {
  const existingTx = await db.query.creditTransactions.findFirst({
    where: eq(creditTransactions.idempotencyKey, params.idempotencyKey),
  })
  if (existingTx) return { alreadyProcessed: true }

  await ensureBalanceRow(params.userId)

  await db.transaction(async (tx) => {
    const [balance] = await tx
      .update(creditBalances)
      .set({ balance: sql`${creditBalances.balance} + ${params.amount}`, updatedAt: new Date() })
      .where(eq(creditBalances.userId, params.userId))
      .returning()

    await tx.insert(creditTransactions).values({
      userId: params.userId,
      type: params.reason === 'purchase' ? 'purchase' : 'grant',
      amount: params.amount,
      balanceAfter: balance.balance,
      reason: params.reason,
      referenceType: params.referenceType,
      referenceId: params.referenceId,
      idempotencyKey: params.idempotencyKey,
    })
  })

  return { alreadyProcessed: false }
}

/** Directly debits credits for an instant (non-reserved) action like a chat message. */
export async function spendCredits(params: {
  userId: string
  amount: number
  reason: string
  referenceType?: string
  referenceId?: string
  idempotencyKey: string
}) {
  const existingTx = await db.query.creditTransactions.findFirst({
    where: eq(creditTransactions.idempotencyKey, params.idempotencyKey),
  })
  if (existingTx) return { alreadyProcessed: true }

  await ensureBalanceRow(params.userId)

  await db.transaction(async (tx) => {
    const [balance] = await tx
      .update(creditBalances)
      .set({ balance: sql`${creditBalances.balance} - ${params.amount}`, updatedAt: new Date() })
      .where(eq(creditBalances.userId, params.userId))
      .returning()

    await tx.insert(creditTransactions).values({
      userId: params.userId,
      type: 'capture',
      amount: -params.amount,
      balanceAfter: balance.balance,
      reason: params.reason,
      referenceType: params.referenceType,
      referenceId: params.referenceId,
      idempotencyKey: params.idempotencyKey,
    })
  })

  return { alreadyProcessed: false }
}

export async function getBalance(userId: string) {
  const row = await ensureBalanceRow(userId)
  return { balance: row.balance, reserved: row.reserved, available: row.balance - row.reserved }
}
