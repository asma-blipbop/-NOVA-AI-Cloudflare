import { createServerFn } from '@tanstack/react-start'
import { ensureDefaultCatalog } from '../lib/catalog.js'
import { getPaymentLink } from '../lib/payment-actions.js'

export const getPricingData = createServerFn({ method: 'GET' }).handler(async () => {
  const { plans, packs } = await ensureDefaultCatalog()
  const planLinks: Record<string, string | null> = {}
  for (const plan of plans) {
    if (plan.priceCents > 0) {
      planLinks[plan.slug] = await getPaymentLink({ data: { target: `plan:${plan.slug}` } })
    }
  }
  const packLinks: Record<string, string | null> = {}
  for (const pack of packs) {
    packLinks[pack.id] = await getPaymentLink({ data: { target: `pack:${pack.id}` } })
  }
  return { plans, packs, planLinks, packLinks }
})
