import { drizzle } from 'drizzle-orm/netlify-db'
import * as schema from './schema.js'

// Temporary compatibility typing: the current Drizzle Netlify DB adapter
// exposes an incomplete inferred type under Cloudflare's TypeScript setup.
// Runtime behavior remains unchanged until the DB is migrated to D1.
export const db: any = drizzle({ schema })
