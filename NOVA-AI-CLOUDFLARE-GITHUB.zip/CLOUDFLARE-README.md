# NOVA AI — Cloudflare preparation

Cette archive contient le projet source NOVA AI avec la configuration Cloudflare Workers/TanStack Start.

Important : l'application utilise encore certains services Netlify (notamment l'authentification et la base de données). Cette archive prépare le runtime Cloudflare mais ne prétend pas migrer ces services.

Déploiement :
1. Importer le projet dans GitHub.
2. Dans Cloudflare : Workers & Pages → Create → Connect to Git.
3. Sélectionner le dépôt.
4. Utiliser `npm run build` comme commande de build.
5. Le déploiement Workers utilise `wrangler deploy`.

Ne pas mettre de secrets dans le code source ou dans GitHub.
